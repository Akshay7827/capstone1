import pytest
from apps import app, Historical_data, calculate_estimation
from bson import ObjectId

@pytest.fixture
def client():
    """Create a test client using the Flask application."""
    with app.test_client() as client:
        yield client

def test_home(client):
    """Test the home page."""
    response = client.get('/')
    assert response.status_code == 200
    assert b'Welcome' in response.data  # Adjust this to match content on your home page

def test_register_get(client):
    """Test the register page loads correctly."""
    response = client.get('/register')
    assert response.status_code == 200
    assert b'Register' in response.data  # Adjust this to match content on your register page
        


# def test_register_post(client):
#     """Test user registration."""
#     response = client.post('/register', data={
#         'username': 'testuser79828vsvvsfslmlsmsf',
#         'password': 'StrongPassword123'
#     })
#     assert response.status_code == 201  # Check if registration was successful
#     assert b'Registerd Successfully' in response.data  # Adjust this to match the success message

        
def test_login_page(client):
    """Test the login page loads correctly."""
    response = client.get('/login')
    assert response.status_code == 200
    assert b'Login' in response.data  # Adjust this to match content on your login page       
        
def test_login_post(client):
    """Test user login."""
    response = client.post('/login_post', data={'username': 'admin', 'password': 'admin'})
    assert response.status_code == 302  # Check if login redirects (usually to dashboard)
    location = response.headers['Location']
    assert 'dashboard' in location  # Check if redirected to the dashboard    
        
def test_logout(client):
    """Test user logout."""
    # First, register and log in a user
    client.post('/login_post', data={'username': 'admin', 'password': 'admin'})
    response = client.get('/logout')
    assert response.status_code == 302  # Check if logout redirects
    location = response.headers['Location']
    assert 'login' in location  # Check if redirected to the login page

        
        
def test_delete_historical_data(client):
    """Test deleting historical data."""
    # Add a sample historical data entry for testing
    inserted_id = Historical_data.insert_one({
        "task_name": "Sample Task",
        "complexity": "Low",
        "size": "Small",
        "task_type": "Sample Type",
        "estimated_effort_hours": 1011111111111,
        "confidence_level": "HighHighwwwwwwwww",
        "estimated_range_hours": "8-12"
    }).inserted_id
    
    # Verify the data is inserted
    s = Historical_data.find_one({"_id": inserted_id})
    assert s is not None

    # Make a request to delete the historical data entry
    response = client.post(f'/remove_task/{inserted_id}')
    
    # Check if the response is a redirect
    assert response.status_code == 302

    # Check if the historical data entry is deleted from the collection
    assert Historical_data.find_one({"_id": inserted_id}) is None


