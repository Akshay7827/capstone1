from flask import Flask, request, render_template, jsonify,  redirect
from pymongo import MongoClient

app = Flask(__name__)
client = MongoClient("mongodb://localhost:27017/")
db = client['estimation']
users = db['users']

class User:
    def __init__(self, username, password):
        self.username = username
        self.password = password

    def save(self):
        user_data = {'username': self.username,'password': self.password}
        users.insert_one(user_data)

@app.route('/')
def home():
    return render_template('register.html')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/register', methods=['POST'])
def register():
    if request.method == "POST":
        data = request.form
        username = data.get('username')
        password = data.get('password')
        existing_user = users.find_one({'username': username})
        if existing_user:
            return jsonify(message="User already exists"), 409
        user = User(username=username, password=password)
        user.save()
        return jsonify(message="User registered successfully"), 201

@app.route('/login_post', methods=['POST'])
def login_post():
    if request.method == "POST":
        data = request.form
        username = data.get('username')
        password = data.get('password')
        # username = request.POST('username')
        # password = request.POST('password')
        print(username,password)
        user = users.find_one({'username': username}) and users.find_one({'password': password})
        if user:
            return jsonify("login successfully"), 200
        return jsonify(message="Invalid credentials"), 401
    
if __name__ == '__main__':
    app.run(debug=True)
